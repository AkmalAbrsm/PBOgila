package Interface;

public interface BendaGeometri {
    /**
     * Method to get the name of the geometric object.
     * @return The name of the geometric object.
     */
    String getNama();
}
